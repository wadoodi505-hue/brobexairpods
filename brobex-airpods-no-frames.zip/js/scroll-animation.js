(function () {
  const sequence = document.querySelector("[data-scroll-sequence]");
  if (!sequence) return;

  const sticky = sequence.querySelector(".sequence-sticky");
  const canvas = sequence.querySelector("[data-sequence-canvas]");
  const progressBar = sequence.querySelector(".sequence-progress span");
  const storyStages = [...sequence.querySelectorAll(".story-copy")];
  const loader = document.getElementById("studio-preloader");
  const loaderProgress = document.getElementById("preloader-progress");
  const loaderStatus = document.getElementById("preloader-text");
  const fallback = sequence.querySelector("[data-sequence-fallback]");
  const context = canvas?.getContext("2d", { alpha: false, desynchronized: true });

  if (!sticky || !canvas || !context) {
    sequence.dataset.sequenceState = "fallback";
    if (fallback) fallback.hidden = false;
    loader?.classList.add("loaded");
    return;
  }

  const TOTAL_FRAMES = 155;
  const INITIAL_FRAMES = 6;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const cacheLimit = () => window.matchMedia("(max-width: 800px)").matches ? 10 : 18;
  const frameUrl = (index) => `assets/frames/ezgif-frame-${String(index + 1).padStart(3, "0")}.png`;
  const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));

  const frameCache = new Map();
  const pending = new Map();
  const failed = new Set();
  let currentFrame = 0;
  let desiredFrame = 0;
  let canvasWidth = 0;
  let canvasHeight = 0;
  let drawFrameId = 0;
  let scrollFrameId = 0;
  let initialLoaded = 0;
  let initialFinished = false;
  let sequenceVisible = true;

  const setLoaderProgress = (value, message) => {
    const percent = Math.round(clamp(value) * 100);
    if (loaderProgress) loaderProgress.style.width = `${percent}%`;
    if (loaderStatus && message) loaderStatus.textContent = `${message} (${percent}%)`;
  };

  const finishLoading = (message) => {
    if (initialFinished) return;
    initialFinished = true;
    setLoaderProgress(1, message || "Product experience ready");
    loader?.classList.add("loaded");
  };

  const trimCache = () => {
    const limit = cacheLimit();
    while (frameCache.size > limit) {
      let victim = null;
      let farthest = -1;
      for (const index of frameCache.keys()) {
        if (index === currentFrame) continue;
        const distance = Math.abs(index - currentFrame);
        if (distance > farthest) {
          farthest = distance;
          victim = index;
        }
      }
      if (victim === null) break;
      frameCache.delete(victim);
    }
  };

  const loadFrame = (index, priority = false) => {
    if (index < 0 || index >= TOTAL_FRAMES) return Promise.resolve(null);
    if (frameCache.has(index)) return Promise.resolve(frameCache.get(index));
    if (failed.has(index)) return Promise.resolve(null);
    if (pending.has(index)) return pending.get(index);

    const promise = new Promise((resolve) => {
      const image = new Image();
      image.decoding = "async";
      image.loading = priority ? "eager" : "lazy";
      image.fetchPriority = priority ? "high" : "low";
      image.onload = async () => {
        try {
          if (typeof image.decode === "function") await image.decode();
        } catch (_) {
          // The decoded image can still be drawn when decode() is unavailable.
        }
        pending.delete(index);
        frameCache.set(index, image);
        trimCache();
        resolve(image);
      };
      image.onerror = () => {
        pending.delete(index);
        failed.add(index);
        resolve(null);
      };
      image.src = frameUrl(index);
    });

    pending.set(index, promise);
    return promise;
  };

  const nearestLoadedFrame = (index) => {
    if (frameCache.has(index)) return frameCache.get(index);
    let nearest = null;
    let distance = Infinity;
    for (const [loadedIndex, image] of frameCache) {
      const nextDistance = Math.abs(loadedIndex - index);
      if (nextDistance < distance) {
        nearest = image;
        distance = nextDistance;
      }
    }
    return nearest;
  };

  const resizeCanvas = () => {
    const rect = sticky.getBoundingClientRect();
    canvasWidth = Math.max(1, Math.round(rect.width || window.innerWidth));
    canvasHeight = Math.max(1, Math.round(rect.height || window.innerHeight));
    const dpr = Math.min(window.devicePixelRatio || 1, window.innerWidth <= 800 ? 1.25 : 1.5);
    canvas.width = Math.round(canvasWidth * dpr);
    canvas.height = Math.round(canvasHeight * dpr);
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    requestDraw();
  };

  const draw = () => {
    drawFrameId = 0;
    const image = nearestLoadedFrame(desiredFrame);
    if (!image || !image.naturalWidth) return;

    context.fillStyle = "#020303";
    context.fillRect(0, 0, canvasWidth, canvasHeight);
    const scale = Math.max(canvasWidth / image.naturalWidth, canvasHeight / image.naturalHeight);
    const width = image.naturalWidth * scale;
    const height = image.naturalHeight * scale;
    context.drawImage(image, (canvasWidth - width) / 2, (canvasHeight - height) / 2, width, height);
    currentFrame = desiredFrame;
  };

  const requestDraw = () => {
    if (!drawFrameId) drawFrameId = window.requestAnimationFrame(draw);
  };

  const warmWindow = (index) => {
    const offsets = [0, 1, -1, 2, -2, 3, 4, 5, 6, -3];
    offsets.forEach((offset, position) => {
      const target = index + offset;
      if (target >= 0 && target < TOTAL_FRAMES) loadFrame(target, position < 2);
    });
  };

  const updateStory = (progress) => {
    const stage = Math.min(storyStages.length - 1, Math.floor(progress * storyStages.length));
    storyStages.forEach((story, index) => story.classList.toggle("active", index === stage));
  };

  const updateSequence = () => {
    scrollFrameId = 0;
    const rect = sequence.getBoundingClientRect();
    const scrollable = Math.max(1, sequence.offsetHeight - sticky.offsetHeight);
    const progress = clamp(-rect.top / scrollable);
    desiredFrame = Math.min(TOTAL_FRAMES - 1, Math.round(progress * (TOTAL_FRAMES - 1)));
    if (progressBar) progressBar.style.transform = `scaleX(${progress})`;
    updateStory(progress);
    if (sequenceVisible) {
      warmWindow(desiredFrame);
      requestDraw();
    }
  };

  const requestSequenceUpdate = () => {
    if (!scrollFrameId) scrollFrameId = window.requestAnimationFrame(updateSequence);
  };

  const handleInitialFrame = (index) => {
    initialLoaded += 1;
    setLoaderProgress(initialLoaded / INITIAL_FRAMES, `Preparing product sequence ${Math.min(initialLoaded, INITIAL_FRAMES)} of ${INITIAL_FRAMES}`);
    if (index === 0 && frameCache.has(0)) {
      desiredFrame = 0;
      requestDraw();
    }
  };

  const start = () => {
    resizeCanvas();
    updateSequence();
    if (reduceMotion) {
      loadFrame(0, true).then((image) => {
        if (image) requestDraw();
        else {
          sequence.dataset.sequenceState = "fallback";
          if (fallback) fallback.hidden = false;
        }
        finishLoading(image ? "Product experience ready" : "Using visual fallback");
      });
      return;
    }

    const firstBatch = Array.from({ length: INITIAL_FRAMES }, (_, index) => index);
    Promise.all(firstBatch.map((index) => loadFrame(index, true).then((image) => {
      handleInitialFrame(index);
      return image;
    }))).then((images) => {
      if (!images[0] && images.every((image) => !image)) {
        sequence.dataset.sequenceState = "fallback";
        if (fallback) fallback.hidden = false;
        finishLoading("Using visual fallback");
        return;
      }
      finishLoading("Product experience ready");
      requestDraw();
    });

    window.setTimeout(() => {
      if (!initialFinished) finishLoading("Product experience ready");
    }, 4500);
  };

  if ("IntersectionObserver" in window) {
    new IntersectionObserver(([entry]) => {
      sequenceVisible = entry.isIntersecting;
      if (sequenceVisible) {
        warmWindow(desiredFrame);
        requestDraw();
      }
    }, { rootMargin: "35% 0px" }).observe(sequence);
  }

  window.addEventListener("resize", resizeCanvas, { passive: true });
  window.addEventListener("scroll", requestSequenceUpdate, { passive: true });
  window.addEventListener("pageshow", requestSequenceUpdate, { passive: true });

  const particles = sequence.querySelector("[data-particles]");
  if (particles && !reduceMotion) {
    const fragment = document.createDocumentFragment();
    for (let index = 0; index < 18; index += 1) {
      const particle = document.createElement("i");
      particle.style.setProperty("--particle-x", `${(index * 37) % 100}%`);
      particle.style.setProperty("--particle-y", `${(index * 61) % 100}%`);
      particle.style.setProperty("--particle-size", `${2 + (index % 3)}px`);
      particle.style.setProperty("--particle-delay", `${(index % 7) * -1.2}s`);
      particle.style.setProperty("--particle-duration", `${8 + (index % 5)}s`);
      fragment.appendChild(particle);
    }
    particles.appendChild(fragment);
  }

  start();
})();